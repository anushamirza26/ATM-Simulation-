# Atm-simulation-
An ATM simulation showing operating system structure code in phython using tkinker
